#include "undistorted_top_view/ocam_functions.h"
#include "undistorted_top_view/Parameters.h"
 
#include <iostream>
#include <string>
#include <exception>

#include <ros/ros.h>
#include <ros/package.h>
#include <tf/transform_broadcaster.h>
#include <nav_msgs/OccupancyGrid.h>
#include <geometry_msgs/PoseArray.h>
#include <nav_msgs/Path.h>

#include <cv_bridge/cv_bridge.h>
// #include <cv.h> ///
// #include <opencv2/opencv.hpp> /// jw add
#include <opencv2/core/core.hpp>
// #include <opencv2/highgui/highgui.hpp>

#include <std_msgs/Float32MultiArray.h>
#include <std_msgs/Bool.h>
#include <pcl_ros/point_cloud.h>
#include <algorithm>

// #include <undistorted_top_view/PhantomVisionNetMsg.h> 
// #include <undistorted_top_view/VisionPhantomnetData.h>
// #include <undistorted_top_view/VisionPhantomnetDataList.h>
#include <undistorted_top_view/ParkingPhantomnetData.h>
#include <undistorted_top_view/ParkingPhantomnetDetection.h>
#include <undistorted_top_view/Bounding_Box.h> 

#include <boost/geometry.hpp>
#include <boost/geometry/geometries/point_xy.hpp>
#include <boost/geometry/geometries/polygon.hpp>
#include <boost/geometry/io/io.hpp>
#include <boost/program_options.hpp>

#define DISTANCE(x1, y1, x2, y2) sqrt((x1 - x2)*(x1 - x2) +(y1 - y2)*(y1 - y2))

using namespace cv;
using namespace std;

// #define m_AVM_IMG_WIDTH  200  //400
// #define m_AVM_IMG_HEIGHT 200  //400
// #define m_REAL_OCCUPANCY_SIZE_X 16.5    // m_AVM_IMG_WIDTH 400PIX == 25Meter
// #define m_REAL_OCCUPANCY_SIZE_Y 16.5    // m_AVM_IMG_HEIGHT 400PIX == 25Meter
int m_AVM_IMG_WIDTH = 0, m_AVM_IMG_HEIGHT = 0;
double m_REAL_OCCUPANCY_SIZE_X = 0.0, m_REAL_OCCUPANCY_SIZE_Y = 0.0;
double m_METER_PER_PIXEL = 0.0;
int m_PADDING_VALUE = 0; 
bool m_PADDING_UP = true;
double m_goal_bias = 0.0;
int m_FULL_IMG_RESOL_WIDTH = 0, m_FULL_IMG_RESOL_HEIGHT = 0, m_CROP_ROI_WIDTH = 0, m_CROP_ROI_HEIGHT = 0;
double m_PARKING_SPOT_WIDTH = 0.0, m_PARKING_SPOT_LENGTH = 0.0, m_FREE_ERASE_GAIN = 0.0;
double m_OCCUPANCY_RATIO = 0.0;
int m_front_rear_dist = 21; /// for 4 images
int m_parking_index = 0;
bool m_ALL_IMAGE_FLAG = false;
string m_PARKING_POSE_TOPIC_NAME = "";

#define M_DEG2RAD  3.1415926/180.0
#define FRONT 0
#define REAR 1
#define LEFT 2
#define RIGHT 3
//////////////////////////////////////////////////////

// #define RESIZE_BAG_TO_ORG 3.75 
// #define PARKING_SPACE 21
// #define OBJ_DET_CONFIDENCE 0.1
// #define ENLARGED_BOX 15
    
ros::Subscriber Sub_phantom_front, Sub_phantom_rear, Sub_phantom_left, Sub_phantom_right;
ros::Subscriber Sub_phantom_front_seg, Sub_phantom_rear_seg, Sub_phantom_left_seg, Sub_phantom_right_seg;
ros::Subscriber Sub_parkingPath;
ros::Subscriber Sub_localizationData, Sub_parkingGoal;

ros::Publisher Pub_AVM_img, Pub_AVM_seg_img, Pub_AVM_seg_img_gray, Pub_AVM_DR;
ros::Publisher Pub_occupancyGridMap;
// ros::Publisher Pub_Boundingbox;

cv::Mat AVM_front, AVM_rear, AVM_left, AVM_right;
cv::Mat AVM_seg_front, AVM_seg_rear, AVM_seg_left, AVM_seg_right;
cv::Mat AVM_seg_front_gray, AVM_seg_rear_gray, AVM_seg_left_gray, AVM_seg_right_gray;

// Calibration Results
ocam_model m_front_model, m_left_model, m_right_model, m_rear_model;

// occupancy grid map for path planning
nav_msgs::OccupancyGrid occupancyGridMap;
int m_dimension = 0, m_gridDim = 0;
double m_gridResol = 0;

struct CARPOSE {
    double x, y, th, vel, dir;
};  CARPOSE m_car;
pcl::PointCloud<pcl::PointXYZRGB>::Ptr m_avm_data(new pcl::PointCloud<pcl::PointXYZRGB>);

bool m_flagParking = false;
// bool m_flagParking = true;  
bool m_flag_goal_empty = false;     // real
unsigned int m_avmDRsize = 0, m_DRcnt = 0;

// ParkingPhantomnetDetection Left_detection;
// typedef struct DETECTIONS{
//     char classification;
//     float probability;
//     float x;
//     float y;
//     float width;
//     float height;
// };
// std::vector<DETECTIONS> Left_detection;

// // Extrinsic Parameters
// double M_front_param[6] = {0.688 * M_DEG2RAD,  21.631 * M_DEG2RAD,   3.103* M_DEG2RAD   ,1.905,   0.033, 0.707 };
// double M_left_param[6] =  {1.133 * M_DEG2RAD,  19.535 * M_DEG2RAD,   92.160* M_DEG2RAD  ,0.0,     1.034, 0.974 };
// double M_right_param[6] = {3.440 * M_DEG2RAD,  18.273 * M_DEG2RAD,  -86.127* M_DEG2RAD  ,0.0,    -1.034, 0.988 };
// double M_back_param[6] =  {0.752 * M_DEG2RAD,  31.238 * M_DEG2RAD,  -178.189* M_DEG2RAD ,-2.973, -0.065, 0.883 };

// // New Extrinsic Parameters 15 mm --> more corect than 9 mm
double M_front_param[6] = {0.672 * M_DEG2RAD,  21.378 * M_DEG2RAD,   1.462* M_DEG2RAD   ,   1.885,   0.038, 0.686 };
double M_left_param[6]  = {0.963 * M_DEG2RAD,  19.283 * M_DEG2RAD,   91.702* M_DEG2RAD  ,   0.0,    1.059, 0.978 };
double M_right_param[6] = {1.714 * M_DEG2RAD,  19.713 * M_DEG2RAD,  -87.631* M_DEG2RAD  ,   0.0,    -1.059, 0.972 };
double M_back_param[6]  = {-0.257 * M_DEG2RAD, 32.645 * M_DEG2RAD,  179.773* M_DEG2RAD ,   -3.002, -0.033, 0.922 };

// // New Extrinsic Parameters 9 mm
// double M_front_param[6] = {0.617 * M_DEG2RAD,  21.397 * M_DEG2RAD,   1.381* M_DEG2RAD   ,   1.880,   0.038, 0.689 };
// double M_left_param[6] =  {0.970 * M_DEG2RAD,  19.231 * M_DEG2RAD,   91.699* M_DEG2RAD  ,   0.0,    1.053, 0.979 };
// double M_right_param[6] = {1.659 * M_DEG2RAD,  19.690 * M_DEG2RAD,  -87.631* M_DEG2RAD  ,   0.0,    -1.053, 0.979 };
// double M_back_param[6] =  {-0.150 * M_DEG2RAD, 32.634 * M_DEG2RAD,  179.708* M_DEG2RAD ,   -2.997, -0.033, 0.924 };

void CallbackParkingPath(const nav_msgs::Path::ConstPtr& msg) {
    m_flagParking = true;
}

void arr2real(int recvX, int recvY, double& outX, double& outY) {
    outX = recvX * m_gridResol - (m_gridResol*m_gridDim - m_gridResol) / 2.0;
    outY = recvY * m_gridResol - (m_gridResol*m_gridDim - m_gridResol) / 2.0;
}

void real2arr(double recvX, double recvY, int& outX, int& outY) {
    outX = (m_gridDim/2.0) + recvX / m_gridResol;
    outY = (m_gridDim/2.0) + recvY / m_gridResol;
}

//Yangwoo===============================================================
double GOAL_G[3] = {0.0, 0.0, (0)};
int modx1 = 0, mody1 = 0, modx2 = 0, mody2 = 0, modx3 = 0, mody3 = 0, modx4 = 0, mody4 = 0;
int modx1free = 0, mody1free = 0, modx2free = 0, mody2free = 0, modx3free = 0, mody3free = 0, modx4free = 0, mody4free = 0;

void coord(double dx, double dy, double xx, double yy, double thh, int& x_, int& y_) {
    double modx = cos(M_PI/2.0 + thh)*dx - sin(M_PI/2.0 + thh)*dy + xx;
    double mody = sin(M_PI/2.0 + thh)*dx + cos(M_PI/2.0 + thh)*dy + yy;
    real2arr(modx, mody, x_, y_);
}

int withinpoint(int x, int y) {
    typedef boost::geometry::model::d2::point_xy<int> point_type;
    typedef boost::geometry::model::polygon<point_type> polygon_type;

    polygon_type poly;
    poly.outer().assign({
        point_type {modx1, mody1}, point_type {modx2, mody2},
        point_type {modx3, mody3}, point_type {modx4, mody4},
        point_type {modx1, mody1}
    });

    point_type p(x, y);

    return boost::geometry::within(p, poly);
}

int withinpoint_free(int x, int y) {
    typedef boost::geometry::model::d2::point_xy<int> point_type;
    typedef boost::geometry::model::polygon<point_type> polygon_type;

    polygon_type poly;
    poly.outer().assign({
        point_type {modx1free, mody1free}, point_type {modx2free, mody2free},
        point_type {modx3free, mody3free}, point_type {modx4free, mody4free},
        point_type {modx1free, mody1free}
    });

    point_type p(x, y);

    return boost::geometry::within(p, poly);
}
/////////////////////////////////////////////////////////////////////////////////////////////////////

void Local2Global(double Lx, double Ly, double &gX, double &gY) {
    gX = m_car.x + (Lx * cos(m_car.th) - Ly * sin(m_car.th));
    gY = m_car.y + (Lx * sin(m_car.th) + Ly * cos(m_car.th));
}

void seg2rgb(cv::Mat input_img, cv::Mat& output_img, cv::Mat& output_img_gray) {
    for (int i = 0 ; i < input_img.rows ; i++) {
        for (int j = 0 ; j < input_img.cols ; j++) {
            // if ((int)input_img.at<uchar>(i, j) != 0 && 
            //     (int)input_img.at<uchar>(i, j) != 1 && 
            //     (int)input_img.at<uchar>(i, j) != 2 && 
            //     (int)input_img.at<uchar>(i, j) != 3 &&
            //     (int)input_img.at<uchar>(i, j) != 4 && 
            //     (int)input_img.at<uchar>(i, j) != 5 &&
            //     (int)input_img.at<uchar>(i, j) != 6 &&
            //     (int)input_img.at<uchar>(i, j) != 9 &&
            //     (int)input_img.at<uchar>(i, j) != 10 &&
            //     (int)input_img.at<uchar>(i, j) != 13 &&
            //     (int)input_img.at<uchar>(i, j) != 14 &&
            //     (int)input_img.at<uchar>(i, j) != 15)
            //     cout << (int)input_img.at<uchar>(i, j) << " " ;
// Segmentation: 14 classes
// (ID and description)
// 0 : background
// 1 : lane - solid, dashed, dotted
// 2 : lane - parking, stop, arrow, etc
// 3 / 연석? 도로 경계?
// 4 : vehicle - all types
// 6 : wheel
// 9 : general - cone, curbstone, parking block, etc
// 10: cycle, bicyclist, motorcyclist
// 14: pedestrian
// 15: freespace
// 17: parking space
// 18: crosswalk
// 19: speed bump
// 20: foot
// 21: head
            if ((int)input_img.at<uchar>(i, j) == 4 || (int)input_img.at<uchar>(i, j) == 6 || (int)input_img.at<uchar>(i, j) == 17) {
                output_img_gray.at<uchar>(i, j) = 255;
                if ((int)input_img.at<uchar>(i, j) == 17) {
                    output_img_gray.at<uchar>(i, j) = 17;
                }
            }
            else
                output_img_gray.at<uchar>(i, j) = 0;

            switch((int)input_img.at<uchar>(i, j)){
                case 0 : // 
                    output_img.at<Vec3b>(i, j)[0] = 78;
                    output_img.at<Vec3b>(i, j)[1] = 56;
                    output_img.at<Vec3b>(i, j)[2] = 24;
                break; 
                case 1 :
                    output_img.at<Vec3b>(i, j)[0] = 0;
                    output_img.at<Vec3b>(i, j)[1] = 0;
                    output_img.at<Vec3b>(i, j)[2] = 255;
                break;  
                case 2 :
                    output_img.at<Vec3b>(i, j)[0] = 0;
                    output_img.at<Vec3b>(i, j)[1] = 0;
                    output_img.at<Vec3b>(i, j)[2] = 255;
                break;  
                case 3 : 
                    output_img.at<Vec3b>(i, j)[0] = 255;
                    output_img.at<Vec3b>(i, j)[1] = 0;
                    output_img.at<Vec3b>(i, j)[2] = 0;
                break;  
                case 4 :  // 
                    output_img.at<Vec3b>(i, j)[0] = 4;
                    output_img.at<Vec3b>(i, j)[1] = 125;
                    output_img.at<Vec3b>(i, j)[2] = 255;
                break;  
                case 5 : 
                    output_img.at<Vec3b>(i, j)[0] = 255;
                    output_img.at<Vec3b>(i, j)[1] = 0;
                    output_img.at<Vec3b>(i, j)[2] = 255;
                break;  
                case 6 :  // 
                    output_img.at<Vec3b>(i, j)[0] = 4;
                    output_img.at<Vec3b>(i, j)[1] = 255;
                    output_img.at<Vec3b>(i, j)[2] = 255;
                break;  
                case 9 : // 
                    output_img.at<Vec3b>(i, j)[0] = 255;
                    output_img.at<Vec3b>(i, j)[1] = 255;
                    output_img.at<Vec3b>(i, j)[2] = 255;
                break;  
                case 10 : 
                    output_img.at<Vec3b>(i, j)[0] = 35;
                    output_img.at<Vec3b>(i, j)[1] = 111;
                    output_img.at<Vec3b>(i, j)[2] = 255;
                break;  
                // case 13 :    // road 
                //     output_img.at<Vec3b>(i, j)[0] = 0;
                //     output_img.at<Vec3b>(i, j)[1] = 255;
                //     output_img.at<Vec3b>(i, j)[2] = 0;
                // break;
                case 14 : 
                    output_img.at<Vec3b>(i, j)[0] = 0;
                    output_img.at<Vec3b>(i, j)[1] = 165;
                    output_img.at<Vec3b>(i, j)[2] = 255;
                break;  
                case 15 : // free(int)(m_REAL_OCCUPANCY_SIZE_X*2.0);
                    output_img.at<Vec3b>(i, j)[0] = 193;
                    output_img.at<Vec3b>(i, j)[1] = 182;
                    output_img.at<Vec3b>(i, j)[2] = 255;
                break;  
                case 17 :    // parking space 
                    output_img.at<Vec3b>(i, j)[0] = 0;
                    output_img.at<Vec3b>(i, j)[1] = 255;
                    output_img.at<Vec3b>(i, j)[2] = 0;
                break;
                default :
                    output_img.at<Vec3b>(i, j)[0] = 0;
                    output_img.at<Vec3b>(i, j)[1] = 0;
                    output_img.at<Vec3b>(i, j)[2] = 0;
            }
        }
    }
    // cout << endl;
}

void preProcessing(cv::Mat input_img, cv::Mat& output_img) {
    //resize, bagfile_size: (512, 288) * 3.75 => (1920, 1080)
    cv::resize( input_img, input_img, cv::Size(m_CROP_ROI_WIDTH, m_CROP_ROI_HEIGHT), 0, 0, cv::INTER_LINEAR );
    // padding
    cv::Mat temp;

    //padding 1920 1208
    if (m_PADDING_UP)
        cv::copyMakeBorder(input_img, temp, m_PADDING_VALUE, 0, 0, 0, cv::BORDER_CONSTANT, cv::Scalar(0,0,0) );
    else
        cv::copyMakeBorder(input_img, temp, 0, m_PADDING_VALUE, 0, 0, cv::BORDER_CONSTANT, cv::Scalar(0,0,0) );
    cv::resize( temp, output_img, cv::Size(m_FULL_IMG_RESOL_WIDTH, m_FULL_IMG_RESOL_HEIGHT), 0, 0, cv::INTER_LINEAR );
}

void fill_avm_img(cv::Mat input_img, cv::Mat& output_img, int col, int row, 
                    double x_,double y_, double *Dir_param, ocam_model *model, 
                    bool gray, int Direction_Mode){
    XY_coord xy;
    xy = InvProjGND(x_, y_, Dir_param[0], Dir_param[1], Dir_param[2], Dir_param[3], Dir_param[4] ,Dir_param[5], model);
    
    if(((xy.x < m_FULL_IMG_RESOL_WIDTH) && (xy.x >= 0)) && ((xy.y < m_FULL_IMG_RESOL_HEIGHT) && (xy.y >= 0))) {
        if(gray)
            output_img.at<uint8_t>(int(row), int(col)) = static_cast<uint8_t>(input_img.at<uchar>(xy.y ,xy.x));
        else{
            output_img.at<cv::Vec3b>(int(row), int(col))[0] = static_cast<uint8_t>(input_img.at<cv::Vec3b>(xy.y, xy.x)[0]);
            output_img.at<cv::Vec3b>(int(row), int(col))[1] = static_cast<uint8_t>(input_img.at<cv::Vec3b>(xy.y, xy.x)[1]);
            output_img.at<cv::Vec3b>(int(row), int(col))[2] = static_cast<uint8_t>(input_img.at<cv::Vec3b>(xy.y, xy.x)[2]);
            // cout << (int)(input_img.at<cv::Vec3b>(xy.y, xy.x)[0]) << " " << (int)(input_img.at<cv::Vec3b>(xy.y, xy.x)[1]) << " " << (int)(input_img.at<cv::Vec3b>(xy.y, xy.x)[2]) << endl;
            // double y = static_cast<uint8_t>(input_img.at<cv::Vec3b>(xy.y, xy.x)[0]);
            // double cb = static_cast<uint8_t>(input_img.at<cv::Vec3b>(xy.y, xy.x)[1]);
            // double cr = static_cast<uint8_t>(input_img.at<cv::Vec3b>(xy.y, xy.x)[2]);
            // output_img.at<cv::Vec3b>(int(row), int(col))[0] = y + 1.403*(cr-128);
            // output_img.at<cv::Vec3b>(int(row), int(col))[1] = y + -0.714*(cb-128)-0.344*(cr-128);
            // output_img.at<cv::Vec3b>(int(row), int(col))[2] = y + 1.773*(cb-128);
        }
    }
}

void Inverse_Warping(cv::Mat input_img, cv::Mat& output_img, int Direction_Mode, bool gray) {
    cv::Mat Processed_img, roi_polygon_img;  /// for 4 images
    preProcessing(input_img, Processed_img);
    if (gray) {
        output_img = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC1);
        roi_polygon_img = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC1);
    }
    else {
        output_img = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC3);
        roi_polygon_img = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC3);
    }

     /// for 4 images
    cv::Point pt_set[6];
    //----ptA---------ptB------
    //--------\------/---------
    //---------\----/----------
    //-----------ptC-----------
    //-----------ptD-----------
    //----------/---\----------
    //---------/-----\---------
    //--------/-------\--------
    //----ptE---------ptF------
    // cv::Point ptA = cv::Point((int)(m_AVM_IMG_WIDTH/m_front_rear_dist), 0);
    // cv::Point ptB = cv::Point((int)((m_front_rear_dist-1)*m_AVM_IMG_WIDTH/m_front_rear_dist), 0);
    // cv::Point ptC = cv::Point((int)(m_AVM_IMG_WIDTH*0.5), (int)(m_AVM_IMG_HEIGHT*0.5)-10);
    // cv::Point ptD = cv::Point((int)(m_AVM_IMG_WIDTH*0.5), (int)(m_AVM_IMG_HEIGHT*0.5)+10);
    // cv::Point ptE = cv::Point((int)(m_AVM_IMG_WIDTH/m_front_rear_dist), m_AVM_IMG_HEIGHT);
    // cv::Point ptF = cv::Point((int)((m_front_rear_dist-1)*m_AVM_IMG_WIDTH/m_front_rear_dist), m_AVM_IMG_HEIGHT);

    //---------------------
    //ptA-------------/-ptB
    //----\---------/------
    //------\--ptC---------
    //---------ptD---------
    //------/------\-------
    //----/-----------\----
    //ptE---------------ptF
    //---------------------
    cv::Point ptA = cv::Point(0,                    m_front_rear_dist);
    cv::Point ptB = cv::Point(m_AVM_IMG_WIDTH-1,    m_front_rear_dist);
    cv::Point ptC = cv::Point((int)(m_AVM_IMG_WIDTH*0.5), (int)(m_AVM_IMG_HEIGHT*0.5)-10);
    cv::Point ptD = cv::Point((int)(m_AVM_IMG_WIDTH*0.5), (int)(m_AVM_IMG_HEIGHT*0.5)+10);
    cv::Point ptE = cv::Point(0,                m_AVM_IMG_HEIGHT-m_front_rear_dist-1);
    cv::Point ptF = cv::Point(m_AVM_IMG_WIDTH-1,    m_AVM_IMG_HEIGHT-m_front_rear_dist-1);
    /// for 4 images

    double x_, y_;
    // Camera Intrinsic & Extrinsic Parameter
    double *Dir_param;
    ocam_model *model;

    if(Direction_Mode == FRONT){
        Dir_param = M_front_param;  model = &m_front_model;
        for(int row = 0; row < (m_AVM_IMG_HEIGHT/2)-1 ; row++){
            for(int col = 0; col < m_AVM_IMG_WIDTH ; col++){
                // IMG coord TO WORLD_coord 
                y_ = (m_REAL_OCCUPANCY_SIZE_X/2.0) - double(col) * m_METER_PER_PIXEL;
                x_ = (m_REAL_OCCUPANCY_SIZE_Y/2.0) - double(row) * m_METER_PER_PIXEL;

                fill_avm_img(Processed_img, output_img, col, row, x_, y_, Dir_param, model, gray, Direction_Mode);
            }
        }
         /// for 4 images
        pt_set[0] = cv::Point(0,0); pt_set[1] = cv::Point(m_AVM_IMG_WIDTH-1,0); pt_set[2] = ptB;
        pt_set[3] = ptC; pt_set[4] = ptA; pt_set[5] = ptA;
    }
    else if(Direction_Mode == REAR){
        Dir_param = M_back_param;   model = &m_rear_model;
        for(int row = m_AVM_IMG_HEIGHT-1; row > (m_AVM_IMG_HEIGHT/2) ; row--){
            for(int col = m_AVM_IMG_WIDTH-1; col > 0 ; col--){
                y_ = -(m_REAL_OCCUPANCY_SIZE_X/2.0) + double(m_AVM_IMG_WIDTH - col) * m_METER_PER_PIXEL;
                x_ = -(m_REAL_OCCUPANCY_SIZE_Y/2.0) + double(m_AVM_IMG_WIDTH - row) * m_METER_PER_PIXEL;

                fill_avm_img(Processed_img, output_img, col, row, x_, y_, Dir_param, model, gray, Direction_Mode);
            }
        }
        /// for 4 images
        pt_set[0] = cv::Point(0,m_AVM_IMG_HEIGHT-1); pt_set[1] = ptE; pt_set[2] = ptD;
        pt_set[3] = ptF; pt_set[4] = cv::Point(m_AVM_IMG_WIDTH,m_AVM_IMG_HEIGHT-1); pt_set[5] = cv::Point(m_AVM_IMG_WIDTH,m_AVM_IMG_HEIGHT-1);
    }
    else if(Direction_Mode == LEFT){
        Dir_param = M_left_param;   model = &m_left_model;
        for(int row = m_AVM_IMG_HEIGHT-1; row> 0 ; row--){
            for(int col = 0; col < (m_AVM_IMG_WIDTH/2)-1 ; col++){
                y_ = (m_REAL_OCCUPANCY_SIZE_X/2.0) -  double(col) * m_METER_PER_PIXEL;
                x_ = -(m_REAL_OCCUPANCY_SIZE_Y/2.0) + double(m_AVM_IMG_WIDTH - row) * m_METER_PER_PIXEL;

                fill_avm_img(Processed_img, output_img, col, row, x_, y_, Dir_param, model, gray, Direction_Mode);
            }
        }
        /// for 4 images
        pt_set[0] = ptA; pt_set[1] = ptC; pt_set[2] = ptD;
        pt_set[3] = ptE; pt_set[4] = ptE; pt_set[5] = ptE;
    }
    else if(Direction_Mode == RIGHT){
        Dir_param = M_right_param;  model = &m_right_model;
        for(int row = 0; row< m_AVM_IMG_HEIGHT ; row++){
            for(int col = m_AVM_IMG_WIDTH-1; col > (m_AVM_IMG_WIDTH/2)-1 ; col--){
                y_ = -(m_REAL_OCCUPANCY_SIZE_X/2.0) + double(m_AVM_IMG_WIDTH - col) * m_METER_PER_PIXEL;
                x_ = (m_REAL_OCCUPANCY_SIZE_Y/2.0)  - double(row) * m_METER_PER_PIXEL;

                fill_avm_img(Processed_img, output_img, col, row, x_, y_, Dir_param, model, gray, Direction_Mode);
            }
        }
        /// for 4 images
        pt_set[0] = ptB; pt_set[1] = ptC; pt_set[2] = ptD;
        pt_set[3] = ptF; pt_set[4] = ptF; pt_set[5] = ptF;
    }

     /// for 4 images
    if (m_flagParking && m_ALL_IMAGE_FLAG) {
        const cv::Point* ppt[1] = { pt_set };
        int npt[] = { 6 };
        cv::fillPoly(roi_polygon_img, ppt, npt, 1, Scalar(255, 255, 255), 8);
        cv::bitwise_and(output_img, roi_polygon_img, output_img);
    }
}

// void push_detection_result(const undistorted_top_view::ParkingPhantomnetData::ConstPtr& msg, std::vector<DETECTIONS> *det){
//     DETECTIONS tmp;
//     det->clear();
//     // std::cout<< "size() : " << msg->detections.size() << std::endl;

//     for (int i = 0 ; i < msg->detections.size() ; i++){
//         tmp.classification = msg->detections[i].classification;

//         if((tmp.classification == PARKING_SPACE) && (msg->detections[i].probability > OBJ_DET_CONFIDENCE)) {
//             // std::cout<< "tmp.x" << tmp.x<<std::endl;
//             tmp.probability = msg->detections[i].probability;
//             tmp.x = msg->detections[i].x - ENLARGED_BOX;
//             tmp.y = msg->detections[i].y - ENLARGED_BOX;
//             tmp.width = msg->detections[i].width + 2*ENLARGED_BOX;
//             tmp.height = msg->detections[i].height + 2*ENLARGED_BOX;
//             det->push_back(tmp);
//         }
//     }
//     // std::cout<< "size() : " << det->size() << std::endl;
// }

// Front
void CallbackPhantom_front(const sensor_msgs::ImageConstPtr& msg) 
{
    if (m_flagParking) {
        cv::Mat cv_frame_resize_pad = cv_bridge::toCvCopy(msg, "bgr8" )->image;
        Inverse_Warping(cv_frame_resize_pad, AVM_front, FRONT, false);
    }
}
// Rear
void CallbackPhantom_rear(const sensor_msgs::ImageConstPtr& msg) 
{
    if (m_flagParking) {
        cv::Mat cv_frame_resize_pad = cv_bridge::toCvCopy(msg, "bgr8" )->image;
        Inverse_Warping(cv_frame_resize_pad, AVM_rear, REAR, false);
    }
}
// Left
void CallbackPhantom_left(const sensor_msgs::ImageConstPtr& msg) 
{
    if (!m_flagParking || m_ALL_IMAGE_FLAG) {
        cv::Mat cv_frame_resize_pad = cv_bridge::toCvCopy(msg, "bgr8" )->image;
        // cvtColor(cv_frame_resize_pad, cv_frame_resize_pad, CV_YCrCb2RGB);
        Inverse_Warping(cv_frame_resize_pad, AVM_left, LEFT, false);
    }
}
// Right
void CallbackPhantom_right(const sensor_msgs::ImageConstPtr& msg) 
{
    if (!m_flagParking || m_ALL_IMAGE_FLAG) {
        cv::Mat cv_frame_resize_pad = cv_bridge::toCvCopy( msg, "bgr8" )->image;
        Inverse_Warping(cv_frame_resize_pad, AVM_right, RIGHT, false);
    }
}

void CallbackPhantom_seg_front(const undistorted_top_view::ParkingPhantomnetData::ConstPtr& msg) {
    if (m_flagParking) {
        // push_detection_result(msg, &Front_detection);
        
        cv::Mat cv_frame_seg = cv_bridge::toCvCopy(msg->segmentation, msg->segmentation.encoding )->image;
        cv::Mat cv_frame_raw_new = cv_bridge::toCvCopy(msg->viz, msg->viz.encoding )->image;
        cv::Mat cv_frame_raw_new_gray = cv_bridge::toCvCopy(msg->viz, msg->segmentation.encoding )->image;
        seg2rgb(cv_frame_seg, cv_frame_raw_new, cv_frame_raw_new_gray);
        Inverse_Warping(cv_frame_raw_new, AVM_seg_front, FRONT, false);
        Inverse_Warping(cv_frame_raw_new_gray, AVM_seg_front_gray, FRONT, true);
    }
}

void CallbackPhantom_seg_rear(const undistorted_top_view::ParkingPhantomnetData::ConstPtr& msg) {
    if (m_flagParking) {
        // push_detection_result(msg, &Rear_detection);

        cv::Mat cv_frame_seg = cv_bridge::toCvCopy( msg->segmentation, msg->segmentation.encoding )->image;
        cv::Mat cv_frame_raw_new = cv_bridge::toCvCopy( msg->viz, msg->viz.encoding )->image;
        cv::Mat cv_frame_raw_new_gray = cv_bridge::toCvCopy( msg->viz, msg->segmentation.encoding )->image;
        seg2rgb(cv_frame_seg, cv_frame_raw_new, cv_frame_raw_new_gray);
        Inverse_Warping(cv_frame_raw_new, AVM_seg_rear, REAR, false);
        Inverse_Warping(cv_frame_raw_new_gray, AVM_seg_rear_gray, REAR, true);
    }
}

//Left Segmentation
void CallbackPhantom_seg_left(const undistorted_top_view::ParkingPhantomnetData::ConstPtr& msg) { 
    if (!m_flagParking || m_ALL_IMAGE_FLAG) {
        cv::Mat cv_frame_seg = cv_bridge::toCvCopy( msg->segmentation, msg->segmentation.encoding )->image;
        cv::Mat cv_frame_raw_new = cv_bridge::toCvCopy( msg->viz, msg->viz.encoding )->image;
        cv::Mat cv_frame_raw_new_gray = cv_bridge::toCvCopy( msg->viz, msg->segmentation.encoding )->image;

        seg2rgb(cv_frame_seg, cv_frame_raw_new, cv_frame_raw_new_gray);
        Inverse_Warping(cv_frame_raw_new, AVM_seg_left, LEFT, false);   // seg to classes (color) 
        Inverse_Warping(cv_frame_raw_new_gray, AVM_seg_left_gray, LEFT, true);  // seg to drivable or non-drivable area (gray)
    }
}

//Right Segmentation
void CallbackPhantom_seg_right(const undistorted_top_view::ParkingPhantomnetData::ConstPtr& msg) {
    if (!m_flagParking || m_ALL_IMAGE_FLAG) {
        cv::Mat cv_frame_seg = cv_bridge::toCvCopy( msg->segmentation, msg->segmentation.encoding )->image;
        cv::Mat cv_frame_raw_new = cv_bridge::toCvCopy( msg->viz, msg->viz.encoding )->image;
        cv::Mat cv_frame_raw_new_gray = cv_bridge::toCvCopy( msg->viz, msg->segmentation.encoding )->image;

        seg2rgb(cv_frame_seg, cv_frame_raw_new, cv_frame_raw_new_gray);
        Inverse_Warping(cv_frame_raw_new, AVM_seg_right, RIGHT, false);
        Inverse_Warping(cv_frame_raw_new_gray, AVM_seg_right_gray, RIGHT, true);
    }
}

void AVMpointCloud(cv::Mat img) {
    int avmCutRange = 0, idxSparse = 1;

    for(int i = avmCutRange ; i < img.size().height - avmCutRange ; i = i+idxSparse){
        for(int j = avmCutRange ; j < img.size().width - avmCutRange ; j = j+idxSparse){
            double x = (m_REAL_OCCUPANCY_SIZE_X / 2.0) - m_METER_PER_PIXEL * i, y = (m_REAL_OCCUPANCY_SIZE_Y/2.0) - m_METER_PER_PIXEL * j, gX, gY;
            Local2Global(x, y, gX, gY);

            pcl::PointXYZRGB pt;
            pt.x = gX;  pt.y = gY;  pt.z = 0.0;

            uint8_t r = static_cast<uint8_t>(img.at<cv::Vec3b>(i,j)[2]), g = static_cast<uint8_t>(img.at<cv::Vec3b>(i,j)[1]), b = static_cast<uint8_t>(img.at<cv::Vec3b>(i,j)[0]);
            uint32_t rgb = ((uint32_t)r << 16 | (uint32_t)g << 8 | (uint32_t)b);
            pt.rgb = *reinterpret_cast<float*>(&rgb);

            m_avm_data->push_back(pt);
        }
    }

    // if (m_flagParking) {
    //     if (m_avm_data->size() > 100000)
    //         m_avm_data->erase(m_avm_data->begin(), m_avm_data->begin() + 10000);
    // } else {
        m_avm_data->erase(m_avm_data->begin(), m_avm_data->begin() + m_avmDRsize);
        m_avmDRsize = m_avm_data->size();
    // }
    
    // cout << m_avm_data->size() << endl;
    Pub_AVM_DR.publish(m_avm_data);
}

void CallbackLocalizationData(const std_msgs::Float32MultiArray::ConstPtr& msg){
    m_car.x = msg->data.at(0);      // x
    m_car.y = msg->data.at(1);      // y
    m_car.th = msg->data.at(2);     // theta
    m_car.vel = msg->data.at(3);    // [m/s]
}

void GetRelCoordsFromCar(double ori_x, double ori_y, double ori_th, double &rel_x, double &rel_y, double &rel_th) {
    double Len = DISTANCE(m_car.x, m_car.y, ori_x, ori_y);
    double alpha = atan2(ori_y - m_car.y, ori_x - m_car.x);
    rel_x = Len * cos(alpha - m_car.th);
    rel_y = Len * sin(alpha - m_car.th);
    rel_th = ori_th - m_car.th;
}

void CallbackParkingGoal(const geometry_msgs::PoseArray::ConstPtr& end) {    //[end] which is the coordinates of the goal
    const int index = m_parking_index;    //0 is cloest
    if (end->poses.size() > 0) {
        m_flag_goal_empty = false;
        GOAL_G[0] = end->poses[index].position.x;
        GOAL_G[1] = end->poses[index].position.y;
        GOAL_G[2] = tf::getYaw(end->poses[index].orientation);

        GOAL_G[0] -= m_goal_bias*cos(GOAL_G[2]);
        GOAL_G[1] -= m_goal_bias*sin(GOAL_G[2]);

        double goalRx = 0.0, goalRy = 0.0, goalRth = 0.0;
        GetRelCoordsFromCar(GOAL_G[0], GOAL_G[1], GOAL_G[2], goalRx, goalRy, goalRth);

        coord(m_PARKING_SPOT_WIDTH/2.0,  -m_PARKING_SPOT_LENGTH/2.0, goalRx, goalRy, goalRth, modx1, mody1);
        coord(m_PARKING_SPOT_WIDTH/2.0,   m_PARKING_SPOT_LENGTH/2.0, goalRx, goalRy, goalRth, modx2, mody2);
        coord(-m_PARKING_SPOT_WIDTH/2.0,  m_PARKING_SPOT_LENGTH/2.0, goalRx, goalRy, goalRth, modx3, mody3);
        coord(-m_PARKING_SPOT_WIDTH/2.0, -m_PARKING_SPOT_LENGTH/2.0, goalRx, goalRy, goalRth, modx4, mody4);

        coord( m_PARKING_SPOT_WIDTH/2.0*m_FREE_ERASE_GAIN, -m_PARKING_SPOT_LENGTH/2.0*m_FREE_ERASE_GAIN, goalRx, goalRy, goalRth, modx1free, mody1free);
        coord( m_PARKING_SPOT_WIDTH/2.0*m_FREE_ERASE_GAIN,  m_PARKING_SPOT_LENGTH/2.0*m_FREE_ERASE_GAIN, goalRx, goalRy, goalRth, modx2free, mody2free);
        coord(-m_PARKING_SPOT_WIDTH/2.0*m_FREE_ERASE_GAIN,  m_PARKING_SPOT_LENGTH/2.0*m_FREE_ERASE_GAIN, goalRx, goalRy, goalRth, modx3free, mody3free);
        coord(-m_PARKING_SPOT_WIDTH/2.0*m_FREE_ERASE_GAIN, -m_PARKING_SPOT_LENGTH/2.0*m_FREE_ERASE_GAIN, goalRx, goalRy, goalRth, modx4free, mody4free);
    }
    else        m_flag_goal_empty = true;
 
}

void occupancyGridmapPub(cv::Mat img) {
    int** arr_obs;
    bool** arr_free;
    arr_obs  = new int*[occupancyGridMap.info.width];
    arr_free = new bool*[occupancyGridMap.info.width];

    for (int x = 0; x < occupancyGridMap.info.width; x++) {
        arr_obs[x]  = new int[occupancyGridMap.info.height];
        arr_free[x] = new bool[occupancyGridMap.info.height];
    } 

    for(int i = 0; i < occupancyGridMap.info.width ; i++) 
        for(int j = 0; j < occupancyGridMap.info.height; j++) {
        arr_obs[i][j]  = 0;
        arr_free[i][j] = false;
    }

    for(int row = 0 ; row < m_AVM_IMG_WIDTH ; row++) 
        for(int col = 0 ; col < m_AVM_IMG_HEIGHT ; col++) {
            // WORLD_coord TO IMG coord
            double y_ = (m_REAL_OCCUPANCY_SIZE_X/2.0) - double(col)*m_METER_PER_PIXEL;
            double x_ = (m_REAL_OCCUPANCY_SIZE_Y/2.0) - double(row)*m_METER_PER_PIXEL;

            int arrX, arrY;
            real2arr(y_, x_, arrY, arrX);
            if ((int)img.at<uint8_t>(int(row), int(col)) == 255 || (int)img.at<uint8_t>(int(row), int(col)) == 17) {
                arr_obs[arrX][arrY]++;
                if ((int)img.at<uint8_t>(int(row), int(col)) == 17)
                    arr_free[arrX][arrY] = true;
            }
        }

    int cnt = 0;
    occupancyGridMap.data.clear();
    occupancyGridMap.data.resize(occupancyGridMap.info.width*occupancyGridMap.info.height);
    for(int i = 0 ; i < occupancyGridMap.info.width ; i++)
        for(int j = 0 ; j < occupancyGridMap.info.height ; j++) {
            if (arr_obs[j][i] > (int)(m_OCCUPANCY_RATIO*(m_AVM_IMG_WIDTH/m_REAL_OCCUPANCY_SIZE_X)))   {
                occupancyGridMap.data[cnt] = 100;

                if (!m_flag_goal_empty && withinpoint(j, i) == 1)
                    occupancyGridMap.data[cnt] = 0;
            }
            else                                            
                occupancyGridMap.data[cnt] = 0;

            if (arr_free[j][i]) 
                if (!m_flag_goal_empty && withinpoint_free(j, i) == 1) 
                    occupancyGridMap.data[cnt] = 0;
            cnt++;
        }

    if (Pub_occupancyGridMap.getNumSubscribers() > 0)
        Pub_occupancyGridMap.publish(occupancyGridMap);
}

int main(int argc, char **argv) {   
    ros::init(argc, argv, "undistorted_top_view_node");
    ros::NodeHandle node;
    ros::NodeHandle priv_nh("~");

    std::string OCAM_CALIB_FILE_PATH;
    node.getParam("ALL_IMAGE_FLAG",       m_ALL_IMAGE_FLAG);
    OCAM_CALIB_FILE_PATH = "/home/joonwooahn/catkin_ws/src/undistorted_top_view/include";
    node.getParam("OCAM_CALIB_FILE_PATH",       OCAM_CALIB_FILE_PATH);
    node.getParam("AVM_IMG_WIDTH",              m_AVM_IMG_WIDTH);
    node.getParam("AVM_IMG_HEIGHT",             m_AVM_IMG_HEIGHT);
    node.getParam("REAL_OCCUPANCY_SIZE_X",      m_REAL_OCCUPANCY_SIZE_X);
    node.getParam("REAL_OCCUPANCY_SIZE_Y",      m_REAL_OCCUPANCY_SIZE_Y);
    node.getParam("OCCUPANCY_RATIO",            m_OCCUPANCY_RATIO);
 
    node.getParam("PADDING_VALUE",              m_PADDING_VALUE);
    node.getParam("PADDING_UP",                 m_PADDING_UP);
    node.getParam("goal_bias",                  m_goal_bias);
    node.getParam("FULL_IMG_RESOL_WIDTH",       m_FULL_IMG_RESOL_WIDTH);
    node.getParam("FULL_IMG_RESOL_HEIGHT",      m_FULL_IMG_RESOL_HEIGHT);
    node.getParam("CROP_ROI_WIDTH",             m_CROP_ROI_WIDTH);
    node.getParam("CROP_ROI_HEIGHT",            m_CROP_ROI_HEIGHT);
    node.getParam("PARKING_SPOT_WIDTH",         m_PARKING_SPOT_WIDTH);
    m_PARKING_SPOT_WIDTH *= 1.1;
    node.getParam("PARKING_SPOT_LENGTH",        m_PARKING_SPOT_LENGTH);
    node.getParam("FREE_ERASE_GAIN",            m_FREE_ERASE_GAIN);
    node.getParam("GRID_RESOLUTION",            m_gridResol);
    node.getParam("front_rear_dist",            m_front_rear_dist);
    node.getParam("parking_index",              m_parking_index);
    
    node.getParam("PARKING_POSE_TOPIC_NAME", m_PARKING_POSE_TOPIC_NAME);

    Sub_parkingPath = node.subscribe("/parkingPath", 1, CallbackParkingPath);  // From doRRT node

    Sub_phantom_left        = node.subscribe("/csi_cam/side_left/image_raw", 1, CallbackPhantom_left);
    Sub_phantom_right       = node.subscribe("/csi_cam/side_right/image_raw", 1, CallbackPhantom_right);
    Sub_phantom_left_seg    = node.subscribe("/parking/phantomnet/side_left", 1 , CallbackPhantom_seg_left);
    Sub_phantom_right_seg   = node.subscribe("/parking/phantomnet/side_right", 1 , CallbackPhantom_seg_right);

    Sub_phantom_front       = node.subscribe("/csi_cam/front_center_svm/image_raw", 1 , CallbackPhantom_front);
    Sub_phantom_rear        = node.subscribe("/csi_cam/rear_center_svm/image_raw", 1, CallbackPhantom_rear);
    Sub_phantom_front_seg   = node.subscribe("/parking/phantomnet/front_center_svm", 1 , CallbackPhantom_seg_front);
    Sub_phantom_rear_seg    = node.subscribe("/parking/phantomnet/rear_center_svm", 1 , CallbackPhantom_seg_rear);

    Sub_localizationData = node.subscribe("/LocalizationData", 1, CallbackLocalizationData);
    // Sub_parkingGoal = node.subscribe("/parking_cands", 1, CallbackParkingGoal);
    Sub_parkingGoal = node.subscribe(m_PARKING_POSE_TOPIC_NAME, 1, CallbackParkingGoal); // get from avm

    Pub_AVM_img         = node.advertise<sensor_msgs::Image>("/AVM_image", 1);
    Pub_AVM_seg_img     = node.advertise<sensor_msgs::Image>("/AVM_seg_image", 1);
    
    Pub_AVM_seg_img_gray = node.advertise<sensor_msgs::Image>("/AVM_seg_image_gray", 1);
    Pub_AVM_DR           = node.advertise<pcl::PointCloud<pcl::PointXYZRGB>>("/AVM_image_DR", 1);
       
    // Load Intrinsic Parameter from Directory**
    get_ocam_model(&m_front_model, (OCAM_CALIB_FILE_PATH + "/calib_results_phantom_190_028_front.txt").c_str());
    get_ocam_model(&m_left_model,  (OCAM_CALIB_FILE_PATH + "/calib_results_phantom_190_022_left.txt").c_str());
    get_ocam_model(&m_right_model, (OCAM_CALIB_FILE_PATH + "/calib_results_phantom_190_023_right.txt").c_str());
    get_ocam_model(&m_rear_model,  (OCAM_CALIB_FILE_PATH + "/calib_results_phantom_190_029_rear.txt").c_str());

    AVM_front = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC3);
    AVM_rear  = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC3); 
    AVM_left  = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC3); 
    AVM_right = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC3);

    AVM_seg_front = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC3);
    AVM_seg_rear  = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC3);
    AVM_seg_left  = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC3);
    AVM_seg_right = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC3);

    AVM_seg_front_gray = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC1);
    AVM_seg_rear_gray  = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC1);
    AVM_seg_left_gray  = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC1);
    AVM_seg_right_gray = cv::Mat::zeros(m_AVM_IMG_WIDTH, m_AVM_IMG_HEIGHT, CV_8UC1);

    cv::Mat aggregated_img, aggregated_seg_img, aggregated_seg_gray;

    double PIXEL_PER_METER = (double)(m_AVM_IMG_WIDTH)/m_REAL_OCCUPANCY_SIZE_X;
    m_METER_PER_PIXEL = (double)(1.0/(double)(PIXEL_PER_METER));
    m_dimension = (int)(m_REAL_OCCUPANCY_SIZE_X*2.0);
    m_gridDim = (int)(m_dimension*(int)(1/m_gridResol));

    occupancyGridMap.header.frame_id = "map";
    occupancyGridMap.info.resolution = m_gridResol;
    occupancyGridMap.info.width = occupancyGridMap.info.height = m_gridDim;
    occupancyGridMap.info.origin.position.x = occupancyGridMap.info.origin.position.y = -m_dimension/2 - m_gridResol*2;
    occupancyGridMap.info.origin.position.z = 0.1;
    occupancyGridMap.data.resize(occupancyGridMap.info.width*occupancyGridMap.info.width);
    Pub_occupancyGridMap = node.advertise<nav_msgs::OccupancyGrid>("/occ_map", 1);

    m_car.x = m_car.y = m_car.th = 0.0;
    m_avm_data->clear();
    m_avm_data->header.frame_id = "map";
    
    cout << "OCam Undistort Node Start !!!" << endl;

    // ros::spin();
    ros::Rate loop_rate(50);
    while(ros::ok()) { 
        // if (!m_flagParking) {
        //     ros::AsyncSpinner spinner(4);
        //     spinner.start();

        if (!m_flagParking) {    //before parking
            aggregated_img      = AVM_left + AVM_right;
            aggregated_seg_img  = AVM_seg_left + AVM_seg_right;
            aggregated_seg_gray = AVM_seg_left_gray + AVM_seg_right_gray;
        } 
        else {
            if (m_ALL_IMAGE_FLAG) {
                aggregated_img      = AVM_front + AVM_rear + AVM_left + AVM_right;
                aggregated_seg_img  = AVM_seg_front + AVM_seg_rear + AVM_seg_left + AVM_seg_right;
                aggregated_seg_gray = AVM_seg_front_gray + AVM_seg_rear_gray + AVM_seg_left_gray + AVM_seg_right_gray;
            }
            else {
                aggregated_img = AVM_front + AVM_rear;
                aggregated_seg_img = AVM_seg_front + AVM_seg_rear;
                aggregated_seg_gray = AVM_seg_front_gray + AVM_seg_rear_gray;
            }
        }
        // imshow("asdf:", aggregated_seg_gray);
        // waitKey(1);

        Pub_AVM_img.publish(cv_bridge::CvImage(std_msgs::Header(), "bgr8", aggregated_img).toImageMsg());
        Pub_AVM_seg_img.publish(cv_bridge::CvImage(std_msgs::Header(), "bgr8", aggregated_seg_img).toImageMsg());
        // Pub_AVM_seg_img_gray.publish(cv_bridge::CvImage(std_msgs::Header(), "mono8", aggregated_seg_gray).toImageMsg());

        occupancyGridmapPub(aggregated_seg_gray);
        AVMpointCloud(aggregated_img);

        ros::spinOnce();
        loop_rate.sleep();
    }
    return 0;
}