# This code runs in Python 3
# -*- coding: utf-8 -*-
import itertools
import copy
import networkx as nx
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
import os, sys
import ast# abstraction of syntax
import math
import csv

# def rad2deg(radian):
#     return radian * 180 / math.pi

def get_shortest_paths_distances(graph, pairs, edge_weight_name):
    distance = {}
    for pair in pairs:
        distance[pair] = nx.dijkstra_path_length(graph, pair[0], pair[1], weight = edge_weight_name)
    return distance

def create_complete_graph(pair_weights, flip_weights = True):

    g = nx.Graph()# odd_degree를 가진 node들로 그래프를 만든다.
    for k, v in pair_weights.items():# k: key, v: value, odd_node로 만든 pair들을 edge로
        wt_i = - v if flip_weights else v
        g.add_edge(k[0], k[1], **{'distance': v, 'weight': wt_i})
    return g

def add_augmenting_path_to_graph(graph, min_weight_pairs):
    graph_aug = nx.MultiGraph(graph.copy())# 기존 그래프를 카피하여 multi graph로 변환, multi graph는 node 사이에 edge를 여러개 추가 가능.
    for pair in min_weight_pairs:# odd degree pair 중, minimum distance를 갖는 edge를 기존 그래프에 추가
        graph_aug.add_edge(pair[0],
                        pair[1],
                        **{'distance': nx.dijkstra_path_length(graph, pair[0], pair[1]) , 'trail' : 'augmented'})# 추가된 edge에는 edge거리와, 추가된 경로라는 (augmented) 표시
    return graph_aug

def create_eulerian_circuit(graph_augmented, graph_original, starting_node = None):
    # global additional_edge# additional edge의 경우는 뒤에 차량으로서 어색한 경로를 거르기 위해 사용
    # additional_edge = []
    additional_edge = []
    euler_circuit = []
    aug_path = ()
    aug_path_pairs = []
    naive_circuit = []

    naive_circuit = list(nx.eulerian_circuit(graph_augmented, source = starting_node))# g*를 이용하여, eulerian circuit 만들기
    # print("naive_circuit", naive_circuit)
    for edge in naive_circuit:
        edge_data = graph_augmented.get_edge_data(edge[0], edge[1])
        # print("edge_data", edge_data)

        if edge_data[0]['trail'] != 'augmented':# 추가된 edge가 아니고 기존 그래프, g에도 있는 경로
            # print("edge_data2", edge_data)
            edge_att = graph_original[edge[0]][edge[1]]
            euler_circuit.append((edge[0], edge[1], edge_att))# 기존 그래프에 있는 경로를 euler_circuit에 추가


        else:# 추가된 edge인데, 두 edge로 node가 이어져 있는 경우, 즉, NODE_start - edge- tmp_node -edge - NODE_fin.
            # print("edge_data3", edge_data)
            # msk
            additional_edge = []
            additional_edge = odd_matching.copy()
            tmp = tuple(sorted([edge[0], edge[1]]))
            additional_edge.remove(tmp)

    
            aug_path = nx.shortest_path(graph_original, edge[0], edge[1], weight = 'distance')# 기존 그래프에서 추가된 edge를 가는 실제 경로를 계산
            aug_path_pairs = list(zip(aug_path[:-1], aug_path[1:]))# 경로 pair생성
            additional_edge += aug_path_pairs# 추가되는 edge를 저장

            for edge_aug in aug_path_pairs:
                edge_aug_att = graph_original[edge_aug[0]][edge_aug[1]]
                euler_circuit.append((edge_aug[0], edge_aug[1], edge_aug_att))# 기존 그래프를 기준으로 odd_degree pair의 경로를 euler_circuit에 추가

    return euler_circuit, additional_edge

def create_cpp_edgelist(euler_circuit):
    cpp_edgelist = {}# dictionary

    for i, e in enumerate(euler_circuit):
        edge = frozenset([e[0], e[1]])

        if edge in cpp_edgelist:
            cpp_edgelist[edge][2]['sequence'] += ', '+ str(i)
            cpp_edgelist[edge][2]['visits'] += 1
        else:
            cpp_edgelist[edge] = e
            cpp_edgelist[edge][2]['sequence'] = str(i)
            cpp_edgelist[edge][2]['visits'] = 1

    return list(cpp_edgelist.values())

def start_node(graph, car_pos_x, car_pos_y, car_pos_heading):
    heading_reasonable_node = []
    source_node = str()# initialization
    # print(math.pi/2)
    for i in range(len(graph.nodes)):
        heading_diff = math.atan2(graph.nodes[list(graph.nodes)[i]]['Y'] - car_pos_y, graph.nodes[list(graph.nodes)[i]]['X'] - car_pos_x)
        
        if abs(car_pos_heading - heading_diff) < math.pi/2:
            # print(heading_diff * 180 / math.pi)
            heading_reasonable_node.append(list(graph.nodes)[i])
    # print(heading_reasonable_node)

    dis = 9999
    for node in heading_reasonable_node:
        dis_ = math.sqrt((graph.nodes[node]['X'] - car_pos_x)**2 + (graph.nodes[node]['Y'] - car_pos_y)**2)
        if dis >= dis_:
            dis = dis_
            source_node = node
    
    return source_node

def distance(x1, y1, x2, y2):
    return math.sqrt((x2-x1)**2 + (y2-y1)**2)


def main():

    interval = 1# way point 사이 간격
    change = 1.63
    visualization = False# 오일로 경로 보기
    car_pos_x = 0.0
    car_pos_y = 0.0
    car_pos_heading = 3.14# radian
    # initialization
    edgelist = []
    nodelist = []
    eulerTour = []



    g = nx.Graph()# 그래프 생성
    edgelist = pd.read_csv('C:/Users/msk93/Desktop/EulerBACKUP/180712/cParkingEdgelist.csv')# full PATH
    nodelist = pd.read_csv('C:/Users/msk93/Desktop/EulerBACKUP/180712/cParkingNodelist.csv')
    # edgelist = pd.read_csv('cParkingEdgelist.csv')# csv 파일에서 edgelist, nodelist 받기
    # nodelist = pd.read_csv('cParkingNodelist.csv')

    # 그래프에 node, edge 정보 쌓기
    for idx, row in edgelist.iterrows():
        g.add_edge(row[0], row[1], **row[2:].to_dict())

    for idx, row in nodelist.iterrows():
        nx.set_node_attributes(g, {row['id']:  row[1:].to_dict()})


    startNode = start_node(g, car_pos_x, car_pos_y, car_pos_heading)
    print("it will start at", startNode)

    ####################### Considering heading when generating the circuit
    #######################################################################
    nodes_in_start_edge = []# find nodes next to the start node
    for edge in list(g.edges()):
        if "'" + startNode + "'" in str(edge):
            edge = list(edge)
            edge.remove(startNode)
            nodes_in_start_edge.append(edge[0])

    next_node = str()
    min_heading = 9999
    for node in nodes_in_start_edge:
        edge_heading = math.atan2(g.nodes[node]['Y'] - g.nodes[startNode]['Y'], g.nodes[node]['X'] - g.nodes[startNode]['X'])


        # for defining a sign, diff <= PI
        if car_pos_heading - edge_heading >= math.pi:
            diff = 2*math.pi - (car_pos_heading - edge_heading)
        else:
            diff = car_pos_heading - edge_heading

        # print(node)
        # print(diff)

        if abs(diff) <= min_heading:
            min_heading = abs(abs(edge_heading) - abs(car_pos_heading))
            next_node = node

    start_edge = [startNode, next_node]# Consitering the car's heading
    # print(nodes_in_start_edge)
    # print(next_node)
    # print(start_edge)
    ####################################################################



    dir_edge = []
    for edge_tuple in list(g.edges):
        if g.edges[edge_tuple]['directed'] == 'yes':
            dir_edge.append(sorted(edge_tuple))
            dir_edge.append(sorted(edge_tuple)[::-1])
    # print("directional_edge:", dir_edge)


    node_positions = {}#node 위치 정보, 저장
    node_positions = {node[0]: (node[1]['X'], node[1]['Y']) for node in g.nodes(data=True)}
    edge_colors = []#edge 색깔 정보 저장
    edge_colors = [e[2]['color'] for e in list(g.edges(data=True))]

    nodes_odd_degree = []
    nodes_odd_degree = [v for v, d in g.degree() if d % 2 ==1]# odd_degree를 가진 node 저장
    # print(nodes_odd_degree)


    odd_node_pairs = []
    odd_node_pairs = list(itertools.combinations(nodes_odd_degree, 2))# odd_degree를 가진 node들로 가능한 pair들을 만들어 저장
    odd_node_pairs_shortest_paths = {}
    odd_node_pairs_shortest_paths = get_shortest_paths_distances(g, odd_node_pairs, 'distance')# 위 pair들 사이의 최소 거리 측정
    # ex) odd_node_pairs_shortest_paths = {('node1', 'node3'): 30, ... }
    # key = node_pair, value = shortest distance
    # print(odd_node_pairs_shortest_paths)


    g_odd_complete = create_complete_graph(odd_node_pairs_shortest_paths, flip_weights = True)# odd_node들만 이용하여 complete graph 만들기
    odd_matching_dupes = set()
    odd_matching_dupes = nx.algorithms.max_weight_matching(g_odd_complete, True)# complete graph에서 최소한의 거리를 갖는 pair들 조합을 찾는다.
    # print(odd_matching_dupes)

    global odd_matching# msk
    odd_matching = list()
    odd_matching = list(pd.unique([tuple(sorted([k, v])) for k, v in odd_matching_dupes]))# odd_matching_dupes를 정렬하여 list로 
    # print("odd_matching", odd_matching)

    g_aug = add_augmenting_path_to_graph(g, odd_matching)# odd_matching, 즉 pair들을 edge로 추가하여 새로운 그래프 g* 생성
    # print(g_aug.edges(data = True))
    # quit()

    # initialization
    global AdditionalEdge
    AdditionalEdge = []

    euler_circuit = []
    euler_circuit, AdditionalEdge = create_eulerian_circuit(g_aug, g, startNode)# euler_circuit만들기
    # print("yo", AdditionalEdge)

    # print("\n")
    if AdditionalEdge == []:
        AdditionalEdge = odd_matching.copy()
    # print("here", AdditionalEdge)



    odd_edge = []
    never_passed_edge = []
    for edge in AdditionalEdge:
        # print(edge)
        if g.degree(edge[0]) == 1 or g.degree(edge[1]) == 1:# 추가된 edge의 양쪽 node 중, 하나라도 degree가 1이면 pass
            pass
        else:# 어색할 수 있는 경로를 odd_edge에 추가
            odd_edge.append(edge)


    for edge in odd_edge:# 어색할 수 있는 경로 중, 계산된 euler_circuit에서 있으면 안되는 조합을 만들어서 never_passed_edge에 저장
        edge = list(edge)
        tmp1 = edge.copy()
        tmp2 = edge.copy()

        tmp1.append(edge[0])
        tmp2.insert(0, edge[1])
        never_passed_edge.append(tmp1)
        never_passed_edge.append(tmp2)
    
    # print(odd_edge)# these edges never be passed, sequencely.
    # print(never_passed_edge)

    # euler_circuit은 지나가는 edge들의 순서가 나와있음.
    # euler_circuit ---> eulerTour, 지나가야하는 node 순서
    # eulerTour는 지나가야하는 node들의 순서가 나와있음.
    for j in range(len(euler_circuit)):
        eulerTour.append(euler_circuit[j][0])
        if j == len(euler_circuit)-1:
            eulerTour.append(euler_circuit[j][1])

    # 어색한 경로가 eulerTour에 있는지 확인
    for never in never_passed_edge:

        if str(never)[1:-1] in str(eulerTour) or eulerTour[:2] != start_edge:# 어색한 경로 발견
            # print("whatTF")
            print("AGAIN")
            python = sys.executable
            os.execl(python, python, *sys.argv)# self start this whole script
            # 어색한 경로가 있을 경우, script를 처음부터 다시 시작

    print("Reasonable eulerTour: {}".format(eulerTour))

    # quit()

    ###########################################################################################
    ###########################################################################################
    #################### euler _circuit에서 경로의 waypoint를 찾아, csv파일로 저장하는 과정
    way_point = []

    for idx, edge in enumerate(euler_circuit):
        tmp_g = g.copy()# 기존 graph를 copy하여 tmp_g에 복사

        # euler_circuit은 edge들로 이루어져 있고, 각 edge가 방향을 고려하는지에 따라서 실행되는 조건문이 다르다.
        # 1. 다음 edge가 directed일 경우: 현재 edge의 끝 node를 움직인다.
        #    이 때, 현재 edge도 directed일 경우, 현재 edge의 시작 node도 움직인다.
        # 2. 다음 edge가 directed가 아니고, 현재 edge가 directed일 경우: 현재 edge의 시작과 끝 node도 움직인다.
        # 3. 다음 edge와 현재 edge가 directed가 아니고 이 전의 edge가 directed일 경우: 현재 edge의 시작 node를 움직인다.
        # 4. 이전, 현재, 다음 edge 모두 undirected일 경우는 기존 그래프 그대로 이용한다.

        # print("=================================")
        # print("current edge: ", edge)
        if str(list(edge[:2])) in str(dir_edge):# current edge is DIRECTED
            # print("3", edge[:2])
            edge_heading = math.atan2(g.nodes[edge[1]]['Y'] - g.node[edge[0]]['Y'], g.nodes[edge[1]]['X'] - g.nodes[edge[0]]['X'])
            # print("\ncurrent edge is dir")
            # change the graph(move nodes of current edge)
            # 다음 edge만 directed
            if idx != 0 and idx != len(euler_circuit)-1 and str(list(euler_circuit[idx+1][:2])) in str(dir_edge) and not str(list(euler_circuit[idx-1][:2])) in str(dir_edge):
                edge_heading_posterior = math.atan2(g.nodes[euler_circuit[idx+1][1]]['Y'] - g.node[euler_circuit[idx+1][0]]['Y'], g.nodes[euler_circuit[idx+1][1]]['X'] - g.nodes[euler_circuit[idx+1][0]]['X'])
                theta = abs(edge_heading_posterior - edge_heading)/2

                tmp_g.nodes[edge[0]]['X']+=change*math.sin(edge_heading)
                tmp_g.nodes[edge[0]]['Y']-=change*math.cos(edge_heading)
                tmp_g.nodes[edge[1]]['X']+=change*math.sin(edge_heading)
                tmp_g.nodes[edge[1]]['Y']-=change*math.cos(edge_heading)

                if edge_heading_posterior - edge_heading >= 0:
                    tmp_g.nodes[edge[1]]['X'] += change*math.tan(theta)*math.cos(edge_heading)
                    tmp_g.nodes[edge[1]]['Y'] += change*math.tan(theta)*math.sin(edge_heading)
                    # print("first x, end x, next edge: dir, previous edge: non-dir, posterior > current")
                else:
                    tmp_g.nodes[edge[1]]['X'] -= change*math.tan(theta)*math.cos(edge_heading)
                    tmp_g.nodes[edge[1]]['Y'] -= change*math.tan(theta)*math.sin(edge_heading)         
                    # print("first x, end x, next edge: dir, previous edge: non-dir, posterior < current")


            elif idx != 0 and idx != len(euler_circuit)-1 and str(list(euler_circuit[idx-1][:2])) in str(dir_edge) and not str(list(euler_circuit[idx+1][:2])) in str(dir_edge):#euler_circuit[idx-1] => previous edge
                edge_heading_previous = math.atan2(g.nodes[euler_circuit[idx-1][1]]['Y'] - g.node[euler_circuit[idx-1][0]]['Y'], g.nodes[euler_circuit[idx-1][1]]['X'] - g.nodes[euler_circuit[idx-1][0]]['X'])
                
                theta = abs(edge_heading - edge_heading_previous)/2
                tmp_g.nodes[edge[0]]['X']+=change*math.sin(edge_heading)
                tmp_g.nodes[edge[0]]['Y']-=change*math.cos(edge_heading)
                tmp_g.nodes[edge[1]]['X']+=change*math.sin(edge_heading)
                tmp_g.nodes[edge[1]]['Y']-=change*math.cos(edge_heading)

                if edge_heading - edge_heading_previous >= 0:# 좌회전
                    tmp_g.nodes[edge[0]]['X'] -= change*math.tan(theta)*math.cos(edge_heading)
                    tmp_g.nodes[edge[0]]['Y'] -= change*math.tan(theta)*math.sin(edge_heading)
                    # print("first x, end x, previous edge: dir, next edge: non-dir, previous < current")

                else:
                    tmp_g.nodes[edge[0]]['X'] += change*math.tan(theta)*math.cos(edge_heading)
                    tmp_g.nodes[edge[0]]['Y'] += change*math.tan(theta)*math.sin(edge_heading)
                    # print("first x, next x, previous edge: dir, next edge: non-dir, previous > current")

            elif idx != 0 and idx != len(euler_circuit)-1 and str(list(euler_circuit[idx-1][:2])) in str(dir_edge) and str(list(euler_circuit[idx+1][:2])) in str(dir_edge):
                edge_heading_posterior = math.atan2(g.nodes[euler_circuit[idx+1][1]]['Y'] - g.node[euler_circuit[idx+1][0]]['Y'], g.nodes[euler_circuit[idx+1][1]]['X'] - g.nodes[euler_circuit[idx+1][0]]['X'])
                edge_heading_previous = math.atan2(g.nodes[euler_circuit[idx-1][1]]['Y'] - g.node[euler_circuit[idx-1][0]]['Y'], g.nodes[euler_circuit[idx-1][1]]['X'] - g.nodes[euler_circuit[idx-1][0]]['X'])

                theta1 = abs(edge_heading_previous - edge_heading)/2#previous
                theta2 = abs(edge_heading_posterior - edge_heading)/2#posterior

                tmp_g.nodes[edge[0]]['X']+=change*math.sin(edge_heading)
                tmp_g.nodes[edge[0]]['Y']-=change*math.cos(edge_heading)
                tmp_g.nodes[edge[1]]['X']+=change*math.sin(edge_heading)
                tmp_g.nodes[edge[1]]['Y']-=change*math.cos(edge_heading)


                if edge_heading - edge_heading_previous >= 0:
                    tmp_g.nodes[edge[0]]['X'] -= change*math.tan(theta1)*math.cos(edge_heading)
                    tmp_g.nodes[edge[0]]['Y'] -= change*math.tan(theta1)*math.sin(edge_heading)
                    if edge_heading_posterior - edge_heading >= 0:
                        tmp_g.nodes[edge[1]]['X'] += change*math.tan(theta2)*math.cos(edge_heading)
                        tmp_g.nodes[edge[1]]['Y'] += change*math.tan(theta2)*math.sin(edge_heading)
                        # print("first x, end x, previous edge: dir, next edge: dir, posterior > current > previous")

                    else:
                        tmp_g.nodes[edge[1]]['X'] -= change*math.tan(theta2)*math.cos(edge_heading)
                        tmp_g.nodes[edge[1]]['Y'] -= change*math.tan(theta2)*math.sin(edge_heading)  
                        # print("first x, end x, previous edge: dir, next edge: dir, posterior < current > previous")

                else:
                    tmp_g.nodes[edge[0]]['X'] += change*math.tan(theta1)*math.cos(edge_heading)
                    tmp_g.nodes[edge[0]]['Y'] += change*math.tan(theta1)*math.sin(edge_heading)
                    if edge_heading_posterior - edge_heading >= 0:
                        tmp_g.nodes[edge[1]]['X'] += change*math.tan(theta2)*math.cos(edge_heading)
                        tmp_g.nodes[edge[1]]['Y'] += change*math.tan(theta2)*math.sin(edge_heading)
                        # print("first x, end x, previous edge: dir, next edge: dir, posterior > current < previous")

                    else:
                        tmp_g.nodes[edge[1]]['X'] -= change*math.tan(theta2)*math.cos(edge_heading)
                        tmp_g.nodes[edge[1]]['Y'] -= change*math.tan(theta2)*math.sin(edge_heading)  
                        # print("first x, end x, previous edge: dir, next edge: dir, posterior < current < previous")



            elif idx == 0 and str(list(euler_circuit[idx+1][:2])) in str(dir_edge):
                edge_heading_posterior = math.atan2(g.nodes[euler_circuit[idx+1][1]]['Y'] - g.node[euler_circuit[idx+1][0]]['Y'], g.nodes[euler_circuit[idx+1][1]]['X'] - g.nodes[euler_circuit[idx+1][0]]['X'])
                tmp_g.nodes[edge[0]]['X']+=change*math.sin(edge_heading)
                tmp_g.nodes[edge[0]]['Y']-=change*math.cos(edge_heading)
                tmp_g.nodes[edge[1]]['X']+=change*math.sin(edge_heading)
                tmp_g.nodes[edge[1]]['Y']-=change*math.cos(edge_heading)
                theta = abs(edge_heading_posterior - edge_heading)/2


                if edge_heading_posterior - edge_heading >= 0:
                    tmp_g.nodes[edge[1]]['X'] += change*math.tan(theta)*math.cos(edge_heading)
                    tmp_g.nodes[edge[1]]['Y'] += change*math.tan(theta)*math.sin(edge_heading)
                    # print("first edge and next edge: dir, posterior > current")
                else:
                    tmp_g.nodes[edge[1]]['X'] -= change*math.tan(theta)*math.cos(edge_heading)
                    tmp_g.nodes[edge[1]]['Y'] -= change*math.tan(theta)*math.sin(edge_heading) 
                    # print("first edge and next edge: dir, posterior < current")

            
            elif idx == len(euler_circuit)-1 and str(list(euler_circuit[idx-1][:2])) in str(dir_edge):
                
                edge_heading_previous = math.atan2(g.nodes[euler_circuit[idx-1][1]]['Y'] - g.node[euler_circuit[idx-1][0]]['Y'], g.nodes[euler_circuit[idx-1][1]]['X'] - g.nodes[euler_circuit[idx-1][0]]['X'])
                tmp_g.nodes[edge[0]]['X']+=change*math.sin(edge_heading)
                tmp_g.nodes[edge[0]]['Y']-=change*math.cos(edge_heading)
                tmp_g.nodes[edge[1]]['X']+=change*math.sin(edge_heading)
                tmp_g.nodes[edge[1]]['Y']-=change*math.cos(edge_heading)
                theta = abs(edge_heading - edge_heading_previous)/2

                if edge_heading - edge_heading_previous >= 0:# 좌회전
                    tmp_g.nodes[edge[0]]['X'] -= change*math.tan(theta)*math.cos(edge_heading)
                    tmp_g.nodes[edge[0]]['Y'] -= change*math.tan(theta)*math.sin(edge_heading)
                    # print("last edge and previous edge: dir, current > previous")
                else:
                    tmp_g.nodes[edge[0]]['X'] += change*math.tan(theta)*math.cos(edge_heading)
                    tmp_g.nodes[edge[0]]['Y'] += change*math.tan(theta)*math.sin(edge_heading)
                    # print("last edge and previous edge: dir, current < previous")


            else:
                tmp_g.nodes[edge[0]]['X']+=change*math.sin(edge_heading)
                tmp_g.nodes[edge[0]]['Y']-=change*math.cos(edge_heading)
                tmp_g.nodes[edge[1]]['X']+=change*math.sin(edge_heading)
                tmp_g.nodes[edge[1]]['Y']-=change*math.cos(edge_heading)
                # print("only current edge: dir")

            # nodes are changed, we have to make the distance be changed as well, 180719
            edge[2]['distance'] = distance(tmp_g.nodes[edge[0]]['X'], tmp_g.nodes[edge[0]]['Y'], tmp_g.nodes[edge[1]]['X'], tmp_g.nodes[edge[1]]['Y'])
            
            way_point.append((tmp_g.nodes[edge[0]]['X'], tmp_g.nodes[edge[0]]['Y'], 1))
            number_of_pt = int(edge[2]['distance'] / interval)
            theta = math.atan2((tmp_g.nodes[edge[1]]['Y'] - tmp_g.nodes[edge[0]]['Y']), (tmp_g.nodes[edge[1]]['X'] - tmp_g.nodes[edge[0]]['X']))
            for i in range(number_of_pt):
                ptx = round(tmp_g.nodes[edge[0]]['X'] + (i+1)*interval*math.cos(theta), 3)
                pty = round(tmp_g.nodes[edge[0]]['Y'] + (i+1)*interval*math.sin(theta), 3)
                if i == number_of_pt - 1:
                    if ptx == tmp_g.nodes[edge[1]]['X'] and pty == tmp_g.nodes[edge[1]]['Y']:
                        break
                way_point.append((ptx, pty, 0))

            if edge == euler_circuit[-1]:# 경로의 마지막 edge인 경우
                way_point.append((tmp_g.nodes[edge[1]]['X'], tmp_g.nodes[edge[1]]['Y'], 1))# 경로의 마지막 node 저장

            tmp_g.clear() 
        

        elif idx != len(euler_circuit)-1 and str(list(euler_circuit[idx+1][:2])) in str(dir_edge):# Next Edge is DIRECTED
            # print("1", edge[:2])
            # 경로의 다음 edge가 directed edge라면, 현재 edge의 끝 node를 옮긴다.
            # print("\nlend x, current edge: non-dir, next edge -> dir")
            edge_heading_posterior = math.atan2(g.nodes[euler_circuit[idx+1][1]]['Y'] - g.node[euler_circuit[idx+1][0]]['Y'], g.nodes[euler_circuit[idx+1][1]]['X'] - g.nodes[euler_circuit[idx+1][0]]['X'])
            edge_heading_previous = math.atan2(g.nodes[euler_circuit[idx+1][1]]['Y'] - g.node[euler_circuit[idx+1][0]]['Y'], g.nodes[euler_circuit[idx+1][1]]['X'] - g.nodes[euler_circuit[idx+1][0]]['X'])

            tmp_g.nodes[edge[1]]['X']+=change*math.sin(edge_heading_posterior)
            tmp_g.nodes[edge[1]]['Y']-=change*math.cos(edge_heading_posterior)
            if idx != 0 and str(list(euler_circuit[idx-1][:2])) in str(dir_edge):# 만약, 이전 edge도 directed edge라면 edge의 시작 node도 같이 옮긴다.
                tmp_g.nodes[edge[0]]['X']+=change*math.sin(edge_heading_previous)
                tmp_g.nodes[edge[0]]['Y']-=change*math.cos(edge_heading_previous)
                # print("current edge: non-dir, previous and next edge: directed")

            # nodes are changed, we have to make the distance be changed as well, 180719
            edge[2]['distance'] = distance(tmp_g.nodes[edge[0]]['X'], tmp_g.nodes[edge[0]]['Y'], tmp_g.nodes[edge[1]]['X'], tmp_g.nodes[edge[1]]['Y'])

            way_point.append((tmp_g.nodes[edge[0]]['X'], tmp_g.nodes[edge[0]]['Y'], 1))# 변환된 그래프에서 현재 edge의 시작 node를 way point에 저장.
            number_of_pt = int(edge[2]['distance'] / interval)
            theta = math.atan2((tmp_g.nodes[edge[1]]['Y'] - tmp_g.nodes[edge[0]]['Y']), (tmp_g.nodes[edge[1]]['X'] - tmp_g.nodes[edge[0]]['X']))
            for i in range(number_of_pt):
                ptx = round(tmp_g.nodes[edge[0]]['X'] + (i+1)*interval*math.cos(theta), 3)
                pty = round(tmp_g.nodes[edge[0]]['Y'] + (i+1)*interval*math.sin(theta), 3)
                if i == number_of_pt - 1:# last node와 겹치는지 확인
                    if ptx == tmp_g.nodes[edge[1]]['X'] and pty == tmp_g.nodes[edge[1]]['Y']:
                        break
                way_point.append((ptx, pty, 0))
            # if edge == euler_circuit[-1]:# 경로의 마지막 edge인 경우, #어차피 마지막 경로가 아니므로 제외
            #     way_point.append((tmp_g.nodes[edge[1]]['X'], tmp_g.nodes[edge[1]]['Y'], 1))# 경로의 마지막 node 저장
            tmp_g.clear()

   

        elif idx != 0 and str(list(euler_circuit[idx-1][:2])) in str(dir_edge):#euler_circuit[idx-1] => previous edge
            # print("\nfirst edge x,  current & next edge: non-dir, previous edga: dir")
            edge_heading_previous = math.atan2(g.nodes[euler_circuit[idx-1][1]]['Y'] - g.node[euler_circuit[idx-1][0]]['Y'], g.nodes[euler_circuit[idx-1][1]]['X'] - g.nodes[euler_circuit[idx-1][0]]['X'])

            # 현재 edge의 시작 node를 옮긴다.
            tmp_g.nodes[edge[0]]['X']+=change*math.sin(edge_heading_previous)
            tmp_g.nodes[edge[0]]['Y']-=change*math.cos(edge_heading_previous)

            # nodes are changed, we have to make the distance be changed as well, 180719
            edge[2]['distance'] = distance(tmp_g.nodes[edge[0]]['X'], tmp_g.nodes[edge[0]]['Y'], tmp_g.nodes[edge[1]]['X'], tmp_g.nodes[edge[1]]['Y'])

            way_point.append((tmp_g.nodes[edge[0]]['X'], tmp_g.nodes[edge[0]]['Y'], 1))
            number_of_pt = int(edge[2]['distance'] / interval)
            theta = math.atan2((tmp_g.nodes[edge[1]]['Y'] - tmp_g.nodes[edge[0]]['Y']), (tmp_g.nodes[edge[1]]['X'] - tmp_g.nodes[edge[0]]['X']))
            for i in range(number_of_pt):
                ptx = round(tmp_g.nodes[edge[0]]['X'] + (i+1)*interval*math.cos(theta), 3)
                pty = round(tmp_g.nodes[edge[0]]['Y'] + (i+1)*interval*math.sin(theta), 3)
                if i == number_of_pt - 1:# last node와 겹치는지 확인
                    if ptx == tmp_g.nodes[edge[1]]['X'] and pty == tmp_g.nodes[edge[1]]['Y']:
                        break
                way_point.append((ptx, pty, 0))
            if edge == euler_circuit[-1]:# 경로의 마지막 edge인 경우
                way_point.append((tmp_g.nodes[edge[1]]['X'], tmp_g.nodes[edge[1]]['Y'], 1))# 경로의 마지막 node 저장
            tmp_g.clear()



        # 0713 NIGHT
        elif idx == 0 and str(list(euler_circuit[idx+1][:2])) in str(dir_edge):# the first edge is not directed
            edge_heading_posterior = math.atan2(g.nodes[euler_circuit[idx+1][1]]['Y'] - g.node[euler_circuit[idx+1][0]]['Y'], g.nodes[euler_circuit[idx+1][1]]['X'] - g.nodes[euler_circuit[idx+1][0]]['X'])
            # print("\nfirst edge o, next edge: directed")
            tmp_g.nodes[edge[1]]['X']+=change*math.sin(edge_heading_posterior)
            tmp_g.nodes[edge[1]]['Y']-=change*math.cos(edge_heading_posterior)


            # nodes are changed, we have to make the distance be changed as well, 180719
            edge[2]['distance'] = distance(tmp_g.nodes[edge[0]]['X'], tmp_g.nodes[edge[0]]['Y'], tmp_g.nodes[edge[1]]['X'], tmp_g.nodes[edge[1]]['Y'])


            way_point.append((tmp_g.nodes[edge[0]]['X'], tmp_g.nodes[edge[0]]['Y'], 1))
            number_of_pt = int(edge[2]['distance'] / interval)
            theta = math.atan2((tmp_g.nodes[edge[1]]['Y'] - tmp_g.nodes[edge[0]]['Y']), (tmp_g.nodes[edge[1]]['X'] - tmp_g.nodes[edge[0]]['X']))
            for i in range(number_of_pt):
                ptx = round(tmp_g.nodes[edge[0]]['X'] + (i+1)*interval*math.cos(theta), 3)
                pty = round(tmp_g.nodes[edge[0]]['Y'] + (i+1)*interval*math.sin(theta), 3)
                if i == number_of_pt - 1:# last node와 겹치는지 확인
                    if ptx == tmp_g.nodes[edge[1]]['X'] and pty == tmp_g.nodes[edge[1]]['Y']:
                        break
                way_point.append((ptx, pty, 0))
            if edge == euler_circuit[-1]:# 경로의 마지막 edge인 경우
                way_point.append((tmp_g.nodes[edge[1]]['X'], tmp_g.nodes[edge[1]]['Y'], 1))# 경로의 마지막 node 저장
            tmp_g.clear()


        elif idx == len(euler_circuit)-1 and str(list(euler_circuit[idx-1][:2])) in str(dir_edge):# the last edge is not directed
            # print("\nlast edge and previous edge: directed")
            edge_heading_previous = math.atan2(g.nodes[euler_circuit[idx-1][1]]['Y'] - g.node[euler_circuit[idx-1][0]]['Y'], g.nodes[euler_circuit[idx-1][1]]['X'] - g.nodes[euler_circuit[idx-1][0]]['X'])
            tmp_g.nodes[edge[0]]['X']+=change*math.sin(edge_heading_previous)
            tmp_g.nodes[edge[0]]['Y']-=change*math.cos(edge_heading_previous)



            # nodes are changed, we have to make the distance be changed as well, 180719
            edge[2]['distance'] = distance(tmp_g.nodes[edge[0]]['X'], tmp_g.nodes[edge[0]]['Y'], tmp_g.nodes[edge[1]]['X'], tmp_g.nodes[edge[1]]['Y'])



            way_point.append((tmp_g.nodes[edge[0]]['X'], tmp_g.nodes[edge[0]]['Y'], 1))
            number_of_pt = int(edge[2]['distance'] / interval)
            theta = math.atan2((tmp_g.nodes[edge[1]]['Y'] - tmp_g.nodes[edge[0]]['Y']), (tmp_g.nodes[edge[1]]['X'] - tmp_g.nodes[edge[0]]['X']))
            for i in range(number_of_pt):
                ptx = round(tmp_g.nodes[edge[0]]['X'] + (i+1)*interval*math.cos(theta), 3)
                pty = round(tmp_g.nodes[edge[0]]['Y'] + (i+1)*interval*math.sin(theta), 3)
                if i == number_of_pt - 1:# last node와 겹치는지 확인
                    if ptx == tmp_g.nodes[edge[1]]['X'] and pty == tmp_g.nodes[edge[1]]['Y']:
                        break
                way_point.append((ptx, pty, 0))
            if edge == euler_circuit[-1]:# 경로의 마지막 edge인 경우
                way_point.append((tmp_g.nodes[edge[1]]['X'], tmp_g.nodes[edge[1]]['Y'], 1))# 경로의 마지막 node 저장
            tmp_g.clear()



        else:
            # print("\nall edge: non-directed")
            way_point.append((g.nodes[edge[0]]['X'], g.nodes[edge[0]]['Y'], 1))# Node는 1로 label
            number_of_pt = int(edge[2]['distance'] / interval)# 각 edge에 찍어야할 way point 개수 정하기
            # print(edge[2]['distance'] / interval)# for DEBUG
            # print("number_Of_pt", number_of_pt)# DEBUG
            theta = math.atan2((g.nodes[edge[1]]['Y'] - g.nodes[edge[0]]['Y']), (g.nodes[edge[1]]['X'] - g.nodes[edge[0]]['X']))

            # waypoint를 계산하여 tuple 형태로 저장
            for i in range(number_of_pt):
                ptx = round(g.nodes[edge[0]]['X'] + (i+1)*interval*math.cos(theta), 3)
                pty = round(g.nodes[edge[0]]['Y'] + (i+1)*interval*math.sin(theta), 3)

                #========180719에 추가, 만약 다음 node보다 넘어가는 경우는 break로 루프 빠져 나오기
        
                if i == number_of_pt -1:# last node와 겹치는지 확인
                    if ptx == g.nodes[edge[1]]['X'] and pty == g.nodes[edge[1]]['Y']:
                        break
                way_point.append((ptx, pty, 0))

            if edge == euler_circuit[-1]:# 경로의 끝자락, 마지막 edge의 끝 node인 경우
                way_point.append((g.nodes[edge[1]]['X'], g.nodes[edge[1]]['Y'], 1))# 경로의 마지막 node 저장
    

    ##########################################################################################
    ##########################################################################################
    ##########################################################################################
    with open('way_point.csv', 'w', newline = '') as myfile:# csv 파일에 기록
        # print("yo")
        way_point_csv = csv.writer(myfile)
        way_point_csv.writerow(['X', 'Y', 'Label'])
        for row in way_point:
            way_point_csv.writerow(row)

    # for point in way_point:# debug
    #     print(point)


    #################### eulerTour를 이용하여, visualize & png 이미지로 저장
    if visualization:

        plt.figure(figsize = (8, 6))
        nx.draw(g, pos = node_positions, edge_color = edge_colors, node_size = 10, node_color = 'red')
        plt.title('MOANA')
        plt.show()

        cpp_edgelist = create_cpp_edgelist(euler_circuit)

        g_cpp = nx.Graph(cpp_edgelist)
        plt.figure(figsize = (8, 6))

        visit_colors = {1: 'lightgray', 2: 'blue'}
        edge_colors = [visit_colors[e[2]['visits']] for e in g_cpp.edges(data=True)]
        node_colors = ['red' if  node in nodes_odd_degree else 'lightgray' for node in g_cpp.nodes()]

        nx.draw_networkx(g_cpp, pos = node_positions, node_size = 20, node_color = node_colors, edge_color = edge_colors, with_labels = False)
        plt.axis('off')
        plt.show()

        ### Visualize with making MOVIE
        visit_colors = {1:'black', 2:'red'}
        edge_cnter = {}
        g_i_edge_colors = []
        for i, e in enumerate(euler_circuit, start=1):
            # i => index, e => element
            edge = frozenset([e[0], e[1]])
            if edge in edge_cnter:
                edge_cnter[edge] += 1
            else:
                edge_cnter[edge] = 1
            
            # Full graph (faded in background)
            nx.draw_networkx(g_cpp, pos = node_positions, node_size = 6, node_color = 'gray', with_labels = False, alpha = 0.07)

            # Edges walked as of iteration i
            euler_circuit_i = copy.deepcopy(euler_circuit[0:i])
            for i in range(len(euler_circuit_i)):
                edge_i = frozenset([euler_circuit_i[i][0], euler_circuit_i[i][1]])
                euler_circuit_i[i][2]['visits_i'] = edge_cnter[edge_i]
            g_i = nx.Graph(euler_circuit_i)
            g_i_edge_colors = [visit_colors[e[2]['visits_i']] for e in g_i.edges(data = True)]

            nx.draw_networkx_nodes(g_i, pos = node_positions, node_size = 6, alpha = 0.6, node_color = 'gray', with_labels = False, linewidths = 0.1)
            nx.draw_networkx_edges(g_i, pos = node_positions, edge_color = g_i_edge_colors, alpha = 0.8)

            plt.axis('off')
            # plt.savefig('img{}.png'.format(i), dpi = 120, bbox_inches = 'tight')
            plt.show()
            plt.close()


if __name__ == '__main__':
    print("Start!\n")
    main()
    print("\nEnd")
